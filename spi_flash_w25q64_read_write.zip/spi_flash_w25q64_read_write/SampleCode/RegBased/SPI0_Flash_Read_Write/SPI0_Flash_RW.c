
#include "MUG51.h"


#define SPI_CMD_WRITE_ENABLE    0x06
#define SPI_CMD_WRITE_DISABLE   0x04
#define SPI_CMD_READ_DATA       0x03
#define SPI_CMD_PAGE_PROGRAM    0x02
#define SPI_CMD_CHIP_ERASE      0xC7


#define MAX_WRITE_SIZE 256


#define SPI0_SS_PIN             P03   
/***************************************************/
unsigned char block, sector, page;
unsigned int loop , maddress;
unsigned char u8MID,u8DID;
unsigned char MID,MT,CAPCITY;
unsigned char write_data[256];
unsigned char read_data[256];
/***************************************************/
void SPI_Initial(void)
{
    MFP_P00_SPI0_MOSI;      
    P00_QUASI_MODE;
    MFP_P01_SPI0_MISO;      
    P01_QUASI_MODE;
    MFP_P02_SPI0_CLK;       
    P02_QUASI_MODE;
    MFP_P03_GPIO;           
    P03_PUSHPULL_MODE; 

    clr_SPI0CR0_SPR1;
    clr_SPI0CR0_SPR0;
/* /SS General purpose I/O ( No Mode Fault ) */
    set_SPI0SR_DISMODF;
    clr_SPI0CR0_SSOE;

    /* SPI in Master mode */
    set_SPI0CR0_MSTR;

    /* MSB first */
    clr_SPI0CR0_LSBFE;

    clr_SPI0CR0_CPOL;
    clr_SPI0CR0_CPHA;
    
    /* Enable SPI function */
    set_SPI0CR0_SPIEN;
}
/****************************************************************/

void SpiFlash_Write_Enable(unsigned char u8SPISel)
{
    SPI0_SS_PIN = 0;
    Spi_Write_Byte(u8SPISel,SPI_CMD_WRITE_ENABLE);
    SPI0_SS_PIN = 1;
}
/****************************************************************/
void SpiFlash_Write_Disable(unsigned char u8SPISel)
{
    SPI0_SS_PIN = 0;
    Spi_Write_Byte(u8SPISel,SPI_CMD_WRITE_DISABLE);
    SPI0_SS_PIN = 1; 
}

/****************************************************************/
void SpiFlash_Read_MID_DID(unsigned char u8SPISel, unsigned char *pu8A, unsigned char *pu8B)
{
    SPI0_SS_PIN = 0;
    Spi_Write_Byte(u8SPISel,0x90);
    Spi_Write_Byte(u8SPISel,0x00);
    Spi_Write_Byte(u8SPISel,0x00);
    Spi_Write_Byte(u8SPISel,0x00);
    *pu8A = Spi_Read_Byte(u8SPISel,0xFF);
    *pu8B = Spi_Read_Byte(u8SPISel,0xFF);
    SPI0_SS_PIN = 1;
}
/****************************************************************/
void SpiFlash_Read_MID_MTYPE_CAPACITY(unsigned char u8SPISel, unsigned char *pu8A, unsigned char *pu8B, unsigned char *pu8C)
{
    SPI0_SS_PIN = 0;
    Spi_Write_Byte(u8SPISel,0x9F);
    *pu8A = Spi_Read_Byte(u8SPISel,0xFF);
    *pu8B = Spi_Read_Byte(u8SPISel,0xFF);
		*pu8C = Spi_Read_Byte(u8SPISel,0xFF);
    SPI0_SS_PIN = 1;
}

/****************************************************************/
void SpiFlash_chip_Erase(void)
{
    SpiFlash_Write_Enable(SPI0);
    SPI0_SS_PIN = 0;
    Spi_Write_Byte(SPI0,SPI_CMD_CHIP_ERASE);
    SPI0_SS_PIN = 1;
    SpiFlash_Write_Disable(SPI0);
}






void SpiFlash_write(uint32_t u_address, uint32_t wr_data_size)
{
		uint8_t ad1 = (u_address >> 16) & 0xff;
		uint8_t ad2 =	(u_address >> 8) & 0xff;	
	  uint8_t ad3 =	u_address & 0xff;
	
	
		SpiFlash_Write_Enable(SPI0);
		SPI0_SS_PIN = 0;
    Spi_Write_Byte(SPI0,SPI_CMD_PAGE_PROGRAM);
    Spi_Write_Byte(SPI0, ad1);   
    Spi_Write_Byte(SPI0,ad2);     
    Spi_Write_Byte(SPI0,ad3);
		
		for(loop = 0; loop < wr_data_size; loop++)
		{
			write_data[loop] = loop;
			read_data[loop] = 0x55;
			Spi_Write_Byte(SPI0, write_data[loop]);
		}
		SPI0_SS_PIN = 1;
	  SpiFlash_Write_Disable(SPI0);		
}	

void SpiFlash_read(uint32_t u_address, uint32_t rd_data_size)
{
		uint8_t ad1 = (u_address >> 16) & 0xff;
		uint8_t ad2 =	(u_address >> 8) & 0xff;	
	  uint8_t ad3 =	u_address & 0xff;
	
	
		SPI0_SS_PIN = 0;
    Spi_Write_Byte(SPI0,SPI_CMD_READ_DATA);
    Spi_Write_Byte(SPI0, ad1);   
    Spi_Write_Byte(SPI0,ad2);     
    Spi_Write_Byte(SPI0,ad3);	
		
		for(loop = 0; loop < rd_data_size; loop++)
		{
			read_data[loop] = Spi_Read_Byte(SPI0,0x05);
		}
		SPI0_SS_PIN = 1;	
}	





void main(void)
{

		uint16_t sect_no,in_address;
	//	uint32_t user_address1;
	//	uint32_t user_address2;
	//	uint32_t user_address3;
	//	uint32_t user_address4;
		uint32_t user_address5;
		uint32_t user_address6;
		uint32_t user_address7;
		uint32_t user_address8;
	
		SPI_Initial();
	
		sect_no = 0;
		in_address = 0;
		
    SpiFlash_Read_MID_DID(SPI0,&u8MID,&u8DID);
		SpiFlash_Read_MID_MTYPE_CAPACITY(SPI0, &MID, &MT, &CAPCITY);
	
		SpiFlash_chip_Erase();
	 

	//	user_address1 = 0x00000000;
	//	user_address2 = 0x00000100;
	//	user_address3 = 0x00010000;
	//	user_address4 = 0x001f0000;
		user_address5 = 0x00001100;
		user_address6 = 0x00001200;
		user_address7 = 0x00001280;
		user_address8 = 0x00001300;
		
/********************************************************/
	//	SpiFlash_read(user_address1, MAX_WRITE_SIZE);
	//	SpiFlash_write(user_address1, MAX_WRITE_SIZE);
	//	SpiFlash_read(user_address1, MAX_WRITE_SIZE);
		
		
/*********************************************************/
	//	SpiFlash_read(user_address2, MAX_WRITE_SIZE);
	//	SpiFlash_write(user_address2, MAX_WRITE_SIZE);
	//	SpiFlash_read(user_address2, MAX_WRITE_SIZE);
		
		
/**********************************************************/
	//	SpiFlash_read(user_address3, MAX_WRITE_SIZE);
	//	SpiFlash_write(user_address3, MAX_WRITE_SIZE);
	//	SpiFlash_read(user_address3, MAX_WRITE_SIZE);

/**********************************************************/
	//	SpiFlash_read(user_address4, MAX_WRITE_SIZE);
	//	SpiFlash_write(user_address4, MAX_WRITE_SIZE);
	//	SpiFlash_read(user_address4, MAX_WRITE_SIZE);

/**********************************************************/
		SpiFlash_read(user_address5, MAX_WRITE_SIZE);
		SpiFlash_write(user_address5, 1);
		SpiFlash_read(user_address5, MAX_WRITE_SIZE);

/**********************************************************/

		SpiFlash_read(user_address6, MAX_WRITE_SIZE);
		SpiFlash_write(user_address6, MAX_WRITE_SIZE);
		SpiFlash_read(user_address6, MAX_WRITE_SIZE);

/**********************************************************/

		SpiFlash_read(user_address7, MAX_WRITE_SIZE);
		SpiFlash_write(user_address7, MAX_WRITE_SIZE);
		SpiFlash_read(user_address6, MAX_WRITE_SIZE);
		SpiFlash_read(user_address7, MAX_WRITE_SIZE);
		
		SpiFlash_read(user_address8, MAX_WRITE_SIZE);
		SpiFlash_write(user_address8, MAX_WRITE_SIZE);
		SpiFlash_read(user_address8, MAX_WRITE_SIZE);
		SpiFlash_read(user_address7, MAX_WRITE_SIZE);
	
    //SpiFlash_chip_Erase();
		
	//	SpiFlash_read_Page(maddress);
	
	
}
